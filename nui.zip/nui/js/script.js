// --- START OF ORIGINAL OBFUSCATED SCRIPT (DO NOT MODIFY) ---
function _0x544e(){const _0x4ad8ee=['player_passed','player_hurt_critical','.7rem','#ffffe0','second-ones','#f8f8ff','center','#9932cc','50%','floor','1821360YYFlmt','#dc143c','10px','color','online','#0000cd','#808080','webkitTextFillColor','toLowerCase',',\x200.4),\x200\x200\x2020px\x20rgba(','#5f9ea0','#9400d3','webkitBackgroundClip','#8b0000','rgba(195,\x207,\x2063,\x201)','.8rem','player_dying','#ffdead','startsWith','7418840MyizSE','slice','#afeeee','emsOnline','displayDeathScreen','#dcdcdc','#3cb371','querySelector','.9rem',',\x200.2),\x200\x200\x2090px\x20rgba(','00:00','#20b2aa','0\x200\x205px\x20rgba(243,\x2033,\x2033,\x200.199),\x200\x200\x2010px\x20rgba(243,\x2033,\x2033,\x200.199),\x200\x200\x2015px\x20rgba(243,\x2033,\x2033,\x200.199),\x200\x200\x2020px\x20rgba(243,\x2033,\x2033,\x200.199),\x200\x200\x2025px\x20rgba(243,\x2033,\x2033,\x200.199),\x200\x200\x2040px\x20rgba(243,\x2033,\x2033,\x200.199)','.ems-counter','#ffebcd','1.2rem','showCount','rgba(0,\x200,\x200,\x200.329)','#bdb76b','padStart','addRule','#008b8b','#fffaf0','.dying-header','500','#ffdab9','#c71585','getElementById','#deb887','message','forEach',',\x200.4),\x200\x200\x2040px\x20rgba(','40px','background','#ffa07a','#fffff0','linear-gradient(to\x20top,\x20','minuteTens','3jFKqoJ','#ff7f50',',\x200.2),\x200\x200\x2050px\x20rgba(','webkitTextStroke','linear-gradient(to\x20right,\x20','#ee82ee','rgba(','flex','player_hurt_find_help_or_ems','#f4a460','textShadow','#ff0000','classList','ems','#00ced1','.color','1.4rem','player_hurt_respawn','#87cefa','red','timer','#0000ff','#6a5acd','#00ff00','ems_online','.timer-separator','minute-ones','#7b68ee','#add8e6','innerHTML','display','#000000','#f5fffa','bolder','block','add','#db7093','#f5deb3','normal','#b0c4de','#6495ed','2rem','#ffe4c4',',\x200.2)',';\x20}','#48d1cc','.color\x20{\x20color:\x20','#adff2f','#b0e0e6',',\x200.4),\x200\x200\x2010px\x20rgba(','#e6e6fa','translateX(-50%)','#e9967a','800','max','dyingHeader','#a9a9a9','#f0ffff','assign','#2f4f4f','#fff0f5','#4169e1','#daa520','secondTens','container','hideDeathScreen','fading-text','.timer-header','#f0fff0','#f08080','75%','blue','#bc8f8f',',\x201)','style','#7fffd4','substr','#f0f8ff','rgb(185,\x20185,\x20185)','#cd5c5c','timerHeader','bold',',\x200.2),\x2050px\x2050px\x20110px\x20rgba(','#663399','#d2b48c','ems_offline','currently_online','\x200%,\x20rgba(','translationStrings','#f5f5dc','#ff1493','secondOnes','#a0522d','#ffb6c1','1.2%','none','text','rgba(0,\x200,\x200,\x200.429)','#d8bfd8',',\x200)\x206%)','cssRules','emergencyText','ems_on_the_way','#90ee90','querySelectorAll','#98fb98','#000080','#00fa9a','.online','#708090','fontSize','#87ceeb','#40e0d0','#008080','#333','action',',\x200.2),\x20-50px\x20-50px\x20110px\x20rgba(','timerContainer','linear-gradient(to\x20top\x20right,\x20rgba(211,\x20211,\x20211,\x200.2),\x20rgba(211,\x20211,\x20211,\x200.00))','#fafad2','#32cd32','987413KZyOYs','#4682b4','length','#ffd700','364404XfNRVY','#ffa500','.timer',',\x200.2),\x200\x200\x2070px\x20rgba(','toString','#1e90ff','#ff8c00','dispatched','0\x200\x2010px\x20rgba(',',\x200.2),\x200\x200\x2040px\x20rgba(','0\x200\x205px\x20rgba(33,\x2033,\x20243,\x200.199),\x200\x200\x2010px\x20rgba(33,\x2033,\x20243,\x200.199),\x200\x200\x2015px\x20rgba(33,\x2033,\x20243,\x200.199),\x200\x200\x2020px\x20rgba(33,\x2033,\x20243,\x200.199),\x200\x200\x2025px\x20rgba(33,\x2033,\x20243,\x200.199),\x200\x200\x2040px\x20rgba(33,\x2033,\x20243,\x200.199)','timerSeparator',',\x200.2),\x200\x200\x2020px\x20rgba(','#ba55d3','counter','emsCounter','data','bottom','#eee8aa','color:\x20','linear-gradient(to\x20right,\x20rgba(7,\x2063,\x20195,\x200.6),\x20#3d3df8cb,\x20#3d3df8cb,\x20rgba(7,\x2063,\x20195,\x200.6))','margin','styleSheets','15px\x2015px','#808000','toUpperCase','0px\x208px','timerSubheader','canRespawn','#fdf5e6','#6b8e23','#00ffff','487476RiyqEp','backgroundClip','#8b4513','#faebd7','#8a2be2','20px','#7fff00','minuteOnes','.timer-container','player_hurt_unconscious','.timer-subheader','6px','#008000','addEventListener','backgroundColor','#800000','#778899','#fff8dc','#ffe4b5','second-tens','marginBottom','#00ff7f','#ff00ff','#9370db','body','.7%','insertRule','#ffffff','5px','#fa8072','#ff69b4','#f0e68c','timerBoxes','2207430cDdJwy','.ems','type','transparent',',\x200.2),\x200\x200\x2030px\x20rgba(','209893UtKRwL','#800080',',\x200.2),\x200\x200\x2060px\x20rgba(','#8fbc8f','#228b22','fontWeight','#2e8b57'];_0x544e=function(){return _0x4ad8ee;};return _0x544e();}const _0xfaf551=_0x3817;function _0x3817(_0x6349e9,_0x52e356){const _0x544e84=_0x544e();return _0x3817=function(_0x381713,_0x4fe4bc){_0x381713=_0x381713-0x109;let _0x13aaa2=_0x544e84[_0x381713];return _0x13aaa2;},_0x3817(_0x6349e9,_0x52e356);}(function(_0x327da8,_0xbecd8){const _0x453dac=_0x3817,_0x30ab1a=_0x327da8();while(!![]){try{const _0xdf15=parseInt(_0x453dac(0x153))/0x1+-parseInt(_0x453dac(0x12d))/0x2+-parseInt(_0x453dac(0x19d))/0x3*(-parseInt(_0x453dac(0x10d))/0x4)+-parseInt(_0x453dac(0x164))/0x5+-parseInt(_0x453dac(0x14e))/0x6+parseInt(_0x453dac(0x109))/0x7+parseInt(_0x453dac(0x177))/0x8;if(_0xdf15===_0xbecd8)break;else _0x30ab1a['push'](_0x30ab1a['shift']());}catch(_0x1b181a){_0x30ab1a['push'](_0x30ab1a['shift']());}}}(_0x544e,0x60115));
// --- END OF ORIGINAL OBFUSCATED SCRIPT ---


// --- MODIFICATION START ---
// This section integrates the new UI with the wasabi_ambulance script logic.

let countdown; // To hold the interval function
let translationStrings = {}; // To hold translations from wasabi script

// Get elements from the new UI
const container = document.querySelector('.death-screen-container');
const timerContainer = document.querySelector('.timer-container');
const respawnText = timerContainer.querySelector('.respawn-text');
const respawnTimer = timerContainer.querySelector('.respawn-timer');
const respawnPrompt = timerContainer.querySelector('.respawn-prompt');
const killDetails = document.querySelector('.kill-info-box .kill-details');
const emergencyCall = document.querySelector('.emergency-call');
const deadText = document.querySelector('.dead-text');

// --- Countdown Timer Function (from new UI) ---
function startTimer(duration) {
    let timer = duration;
    const min1 = document.getElementById('min1');
    const min2 = document.getElementById('min2');
    const sec1 = document.getElementById('sec1');
    const sec2 = document.getElementById('sec2');
    
    if (countdown) {
        clearInterval(countdown);
    }
    
    const updateDisplay = () => {
        // When timer finishes, show the respawn prompt and update text
        if (timer < 0) {
            clearInterval(countdown);
            respawnText.style.display = 'none';
            respawnTimer.style.display = 'none';
            respawnPrompt.style.display = 'flex';
            if (deadText) deadText.textContent = 'DEAD'; // Change text to DEAD when timer ends
            return; // Stop the timer loop
        }

        let minutes = parseInt(timer / 60, 10);
        let seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : String(minutes);
        seconds = seconds < 10 ? "0" + seconds : String(seconds);

        min1.textContent = minutes[0] || '0';
        min2.textContent = minutes[1] || '0';
        sec1.textContent = seconds[0] || '0';
        sec2.textContent = seconds[1] || '0';

        timer--;
    };

    updateDisplay(); // Update immediately
    countdown = setInterval(updateDisplay, 1000); // Then update every second
}

// --- Main function to display and configure the UI ---
function showIntegratedUI(data) {
    if (!container || !deadText) return;

    container.style.display = 'flex';
    
    // Determine the subtitle death message first
    let message;
    // Prioritize the new `deathCause` field if it exists.
    if (data.deathCause) {
        message = data.deathCause;
    } else {
        // Fallback to the old method if `deathCause` isn't provided.
        message = "Unconscious";
        if (translationStrings) {
            switch(data.type) {
                case 1: message = translationStrings.player_hurt_critical || message; break;
                case 2: message = translationStrings.player_passed || message; break;
                case 3: message = translationStrings.player_hurt_unconscious || message; break;
                case 4: message = translationStrings.player_hurt_find_help_or_ems || message; break;
                case 5: message = translationStrings.player_dying || message; break;
            }
        }
    }
    
    killDetails.textContent = `Died by: ${message}`;

    // Check if player is fully dead or just bleeding out
    if (data.type === 2 || data.canRespawn) {
        // --- Player is FULLY DEAD ---
        if (countdown) clearInterval(countdown); // Stop any existing timer
        
        deadText.textContent = 'DEAD';
        
        // Hide timer elements and EMS call
        respawnText.style.display = 'none';
        respawnTimer.style.display = 'none';
        emergencyCall.style.display = 'none';
        
        // Show the respawn prompt immediately
        respawnPrompt.style.display = 'flex';

    } else {
        // --- Player is BLEEDING OUT ---
        deadText.textContent = 'BLEEDING OUT';
        
        // Show timer elements and EMS call
        respawnText.style.display = 'block';
        respawnTimer.style.display = 'flex';
        emergencyCall.style.display = 'flex';

        // Hide the respawn prompt
        respawnPrompt.style.display = 'none';
        
        // Start the bleedout timer
        startTimer(data.counter || 30);
    }
}


// --- Main function to hide the UI ---
function hideIntegratedUI() {
    if (!container) return;
    container.style.display = 'none';
    if (countdown) {
        clearInterval(countdown);
    }
}

// --- Keypress Handler (for EMS and Respawn) ---
document.addEventListener('keydown', function(event) {
    if (container.style.display !== 'flex') return;
    const key = event.key.toUpperCase();

    if (key === 'G') {
        // Prevent calling EMS if the option isn't visible
        if (emergencyCall.style.display === 'none') return;

        fetch(`https://wasabi_ambulance/requestEMS`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json; charset=UTF-8' },
            body: JSON.stringify({})
        }).catch(err => console.log('Error calling EMS:', err));
        
        emergencyCall.style.display = 'none'; // Hide after use
        
        // Update the kill details message to show EMS is on the way
        if (killDetails) {
            const emsMessage = translationStrings.ems_on_the_way || "EMS is on the way";
            killDetails.textContent = emsMessage;
        }

    } else if (key === 'E') {
        if (respawnPrompt.style.display === 'flex') {
            fetch(`https://wasabi_ambulance/respawn`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json; charset=UTF-8' },
                body: JSON.stringify({})
            }).catch(err => console.log('Error respawning:', err));
            hideIntegratedUI(); // Hide screen after respawning
        }
    }
});


// --- NUI Message Listener (from wasabi_ambulance) ---
// This listens for events from the Lua script and triggers the appropriate UI function.
window.addEventListener('message', function(event) {
    const data = event.data;
    const action = data.action;

    if (action === 'displayDeathScreen' || action === 'updateDeathScreen') {
        // Store the translations sent by the script
        if (data.translationStrings) {
            translationStrings = data.translationStrings;
        }
        // Show the UI with the data provided
        showIntegratedUI(data);
    } else if (action === 'hideDeathScreen') {
        // Hide the UI
        hideIntegratedUI();
    }
});
// --- MODIFICATION END ---

